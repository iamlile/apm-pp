(function() {
	'use strict';
	
	pinpointApp.constant('filterConfig', {
	    FILTER_DELIMETER: "^",
	    FILTER_ENTRY_DELIMETER: "|"
	});
})();